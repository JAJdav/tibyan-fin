import pandas as pd, numpy as np, json, subprocess, sys, os, shutil
from sklearn.metrics import average_precision_score, roc_auc_score
import lightgbm as lgb
from sklearn.ensemble import IsolationForest
O='out'
F=pd.read_parquet(f'{O}/features.parquet'); feats=json.load(open(f'{O}/feature_list.json'))
gt=pd.read_csv(f'{O}/eval_only_ground_truth.csv.gz')
print('--- sanity'); print('const cols:',[c for c in feats if F[c].nunique()<=1]); print('nan:',int(F[feats].isna().sum().sum()))
cust_split=F.dropna(subset=['customer_id']).groupby('customer_id').split.nunique(); print('customers in >1 split:',int((cust_split>1).sum()))
# 1. causality: rebuild on first 60% of rows; features of those rows must be identical
raw=pd.read_csv('data/transactions.csv',low_memory=False)
cut=raw.sort_values(['timestamp','txn_id']).iloc[:int(len(raw)*.6)]
os.makedirs('tmp_trunc',exist_ok=True)
cut.to_csv('tmp_trunc/transactions.csv',index=False)
for f in ['customers','merchants','devices']: shutil.copy(f'data/{f}.csv',f'tmp_trunc/{f}.csv')
subprocess.run([sys.executable,'-W','ignore','-I','code/build_features.py','tmp_trunc','tmp_trunc_out'],capture_output=True,check=True)
T=pd.read_parquet('tmp_trunc_out/features.parquet').set_index('txn_id'); A=F.set_index('txn_id').loc[T.index]
bad={c:int((~np.isclose(T[c].astype(float),A[c].astype(float),equal_nan=True,atol=1e-6)).sum()) for c in feats}
bad={k:v for k,v in bad.items() if v}; print('--- causality: features that change when future rows are removed:',bad or 'none')
# 2. baselines
tr,va,te=[F[F.split==s] for s in ['train','val','test']]
def fit(target,cols,seed=0):
    p=dict(objective='binary',learning_rate=.05,num_leaves=31,min_child_samples=20,feature_fraction=.8,bagging_fraction=.8,bagging_freq=1,scale_pos_weight=5,verbose=-1,seed=seed)
    m=lgb.train(p,lgb.Dataset(tr[cols],tr[target]),1000,valid_sets=[lgb.Dataset(va[cols],va[target])],callbacks=[lgb.early_stopping(50,verbose=False)])
    return m
def report(name,target,cols):
    m=fit(target,cols); pv,pt=m.predict(va[cols]),m.predict(te[cols])
    thr=np.quantile(pv,1-0.03)  # review top 3% of volume (picked on val)
    flag=pt>=thr; y=te[target].values
    rec=flag[y==1].mean(); prec=y[flag].mean()
    g=te[['txn_id']].merge(gt,on='txn_id'); hn=g.gt_hard_negative.values==1
    print(f'{name:34s} test PR-AUC {average_precision_score(y,pt):.3f} ROC {roc_auc_score(y,pt):.3f} | top-3% flags: recall {rec:.2f} precision {prec:.2f} | hard-neg flagged {flag[hn].mean():.3f} (n={hn.sum()})')
    return m
print('--- LightGBM baselines (train->val early stop->test)')
suspects=['is_emulator','basket_mismatch_score','category_mismatch_flag','device_other_customers','device_n_customers_so_far']
m1=report('FRAUD all clean features','isFraud',feats)
report('FRAUD w/o suspect signals','isFraud',[c for c in feats if c not in suspects])
m2=report('AML all clean features','isMoneyLaundering',feats)
report('AML w/o suspect signals','isMoneyLaundering',[c for c in feats if c not in suspects])
# naive: amount only
report('FRAUD amount+kind only (floor)','isFraud',['amount','amount_log','is_checkout','is_refund','is_payout','is_p2p_transfer'])
imp=pd.Series(m1.feature_importance('gain'),index=feats).sort_values(ascending=False); print('--- top fraud features by gain share'); print((imp/imp.sum()).head(12).round(3).to_string())
# 3. isolation forest (unsupervised detector)
beh=[c for c in feats if c.startswith(('out_','amount_z','secs','amount_vs','category_freq','hour_bucket','in_','pair','bidir','dest_','orig_'))]+['amount_log','hour']
iso=IsolationForest(n_estimators=200,contamination='auto',random_state=0,n_jobs=-1).fit(tr[beh]); s=-iso.score_samples(te[beh])
for tgt in ['isFraud','isMoneyLaundering']: print(f'IsolationForest test ROC-AUC {tgt}: {roc_auc_score(te[tgt],s):.3f}  PR-AUC {average_precision_score(te[tgt],s):.3f}')
