# ZidPay fraud + AML: cleaned, leak-free modelling data

Rebuild: `python build_features.py <raw_dir> <out_dir>` (about 30 s). Check: `python validate.py`.

## Files
| File | Use |
| --- | --- |
| `features.parquet` | 128,070 rows x (keys + 105 features + 2 targets + `split`). One row per transaction. |
| `feature_list.json` | The 105 column names to train on. Keys, targets, `split` and `split_group` are NOT features. |
| `eval_only_ground_truth.csv.gz` | `gt_scenario_type`, `gt_hard_negative`, `laundering_typology` per `txn_id`. For reporting only. Never train on it. |
| `customers_clean.csv`, `merchants_clean.csv`, `devices_clean.csv` | Entity tables for the Graph and Profiling engines, with label-bearing columns removed. |
| `build_features.py`, `validate.py` | Pipeline and checks. |

Targets: `isFraud` (CatBoost fraud model), `isMoneyLaundering` (LightGBM AML model; a subset of fraud).
`-1` in a feature means "not applicable or no history yet" (for example refund fields on a checkout).

## What was fixed
| Problem found | Fix |
| --- | --- |
| `gt_*`, `laundering_typology` in the data | Removed from features. Kept only in `eval_only_ground_truth.csv.gz`. `gt_role` and `gt_scenario_id` removed from customers and merchants. |
| `devices.device_kind` (ring_shared = fraud) | Dropped. Replaced by observable sharing counts built from history: `device_other_customers`, `ip_subnet_other_customers`, `customers_per_card_so_far`. |
| Useless `merchants.cr_status` (all "active") | Dropped. Replaced by `mer_cr_expired_at_txn`, computed at transaction time. |
| 520 transactions before account opening | `pre_open_txn` flag; `account_age_days` clipped to 0. |
| Balance maths broken in 12.6% of rows | `balance_mismatch` flag and `amount_to_balance` ratio. No balance-delta features. |
| Structural nulls (payout, p2p, refund) | Kind flags (`is_checkout`, `is_refund`, `is_payout`, `is_p2p_transfer`), `has_basket`, `has_device`, `has_card`; `-1` fill. |
| VAT mismatch, shared director, shared phone/card | `mer_vat_inconsistent`, `mer_shared_director`, `cust_shared_phone`, `cust_shared_card`. |
| Naive splits break (rings span up to 55 days, fraud is 0.1% in April) | Entity-disjoint split: each fraud scenario stays whole, and each customer stays in one split. Result: train 76,105 / val 25,399 / test 26,566 rows at about 1.7-1.9% fraud each. |
| Time leakage in velocity/graph features | Every rolling or "so far" feature uses only strictly earlier rows. Verified: rebuilding on the first 60% of rows gives identical features. |

## Features by design component
| Design box | Columns |
| --- | --- |
| Shared feature engineering (velocity) | `out_cnt_*`, `out_sum_*` (1h, 24h, 72h, 7d), `secs_since_prev_txn`, `in_cnt_*`, `in_sum_*`, `in_out_ratio_7d` |
| CatBoost fraud | All features. Strongest signals are merchant dynamics (`mer_refund_rate_*`, `mer_checkout_cnt_7d`, `payout_vs_7d_sales`) and refund fields (`refund_amount_ratio`, `refund_to_different_instrument`). |
| LightGBM AML | All features. Focus on `pair_*`, `bidirectional_pair`, `dest_unique_senders_so_far`, `payout_covers_n_checkouts`. |
| Isolation Forest | Behaviour columns only (velocity, profiling, graph counts). Weak on its own (ROC-AUC about 0.7). |
| Dynamic risk rules | `out_cnt_1h`, `balance_mismatch`, `kyc_not_verified`, `pep_flag`, `mer_director_pep`, `is_vpn_or_proxy`, `mer_cr_expired_at_txn`, `kyb_risk_score`, `refund_amount_ratio`, `device_new_for_customer` |
| Profiling engine | `amount_z_vs_own_history`, `amount_vs_prev_max`, `category_freq_so_far`, `hour_bucket_freq_so_far`, `device_new_for_customer`, `device_is_primary` |
| Graph engine | Edges from `features.parquet` keys: `nameOrig` to `nameDest` (node types C, M, S), plus customer-to-`device_id`, `ip_subnet_hash`, `card_hash` links. Node attributes from the clean entity tables. |

## Baseline (LightGBM, train -> val early stop -> test; threshold = top 3% of val scores)
| Setup | Fraud PR-AUC | Fraud recall | Hard negatives flagged |
| --- | --- | --- | --- |
| All features | 0.987 | 0.99 | 4.4% |
| No static entity attributes (merchant/device age, KYB, etc.) | 0.990 | 1.00 | 6.1% |
| Behaviour + graph only | 0.990 | 0.99 | 4.7% |
| Amount + kind only (floor) | 0.19 | 0.33 | 8.5% |

## Caveats to state in your pitch
- The data is easy: even behaviour-only features reach PR-AUC about 0.99. Fraud merchants are about 33 days old against 1,849 for normal ones, and ring devices about 31 days against 908. High scores are expected, not a sign of a bug.
- Precision at a 3% review budget is capped near 0.6, because only about 1.85% of transactions are fraud. Compare models on precision at 1% and 2% budgets, and on the share of hard negatives flagged (family shared devices, seasonal spikes, high-refund legitimate stores).
- Normal p2p amounts never exceed 1,500, and fraud p2p shows up through that artifact. Treat p2p results with caution.
- Only 48 fraud scenarios exist (18 rings, 30 refund-abuse), so the test set holds about 4 rings and 6 abuse cases. Report results with that in mind.
