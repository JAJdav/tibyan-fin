"""ZidPay fraud/AML: clean raw data, drop leaks, build causal features, entity-disjoint split.

Usage: python build_features.py RAW_DIR OUT_DIR
Every rolling/"so far" feature uses only rows strictly before the current transaction.
"""
import sys, json, hashlib
import numpy as np, pandas as pd

RAW, OUT = sys.argv[1], sys.argv[2]
import os; os.makedirs(OUT, exist_ok=True)

t = pd.read_csv(f"{RAW}/transactions.csv", low_memory=False, parse_dates=["timestamp"])
c = pd.read_csv(f"{RAW}/customers.csv", parse_dates=["account_open_date", "kyc_verified_date"])
m = pd.read_csv(f"{RAW}/merchants.csv", parse_dates=["cr_issue_date", "cr_expiry_date", "onboarding_date"])
dv = pd.read_csv(f"{RAW}/devices.csv", parse_dates=["first_seen"])
t = t.sort_values(["timestamp", "txn_id"]).reset_index(drop=True)
n = len(t)
ts = (t.timestamp.astype("int64") // 10**9).to_numpy()  # seconds
H, D = 3600, 86400

# ---------------------------------------------------------------- 1. keep GT columns out of features
GT_COLS = ["gt_scenario_type", "gt_scenario_id", "gt_hard_negative", "laundering_typology"]
eval_meta = t[["txn_id"] + GT_COLS].copy()  # evaluation-only, never a feature

# ---------------------------------------------------------------- helpers
def window_stats(ev_key, ev_ts, ev_val, q_key, q_ts, W):
    """For each query: count and sum of events with same key and ts in [q_ts-W, q_ts). W=None -> all prior."""
    cnt = np.zeros(len(q_ts)); sm = np.zeros(len(q_ts))
    ev = pd.DataFrame({"k": ev_key, "ts": ev_ts, "v": ev_val}).dropna(subset=["k"]).sort_values(["k", "ts"])
    groups = {k: (g.ts.to_numpy(), np.concatenate([[0], np.cumsum(g.v.to_numpy())])) for k, g in ev.groupby("k")}
    q = pd.DataFrame({"k": q_key, "ts": q_ts, "i": np.arange(len(q_ts))}).dropna(subset=["k"])
    for k, g in q.groupby("k"):
        if k not in groups: continue
        et, cs = groups[k]
        hi = np.searchsorted(et, g.ts.to_numpy(), side="left")
        lo = np.zeros_like(hi) if W is None else np.searchsorted(et, g.ts.to_numpy() - W, side="left")
        cnt[g.i.to_numpy()] = hi - lo
        sm[g.i.to_numpy()] = cs[hi] - cs[lo]
    return cnt, sm

def first_seen_pairs(a, b):
    """first timestamp each (a,b) pair appears, as DataFrame with columns a,b,ts."""
    d = pd.DataFrame({"a": a, "b": b, "ts": ts}).dropna(subset=["a", "b"])
    return d.groupby(["a", "b"], as_index=False).ts.min()

def distinct_before(a, b):
    """# distinct b seen with a strictly before each row (and whether this exact (a,b) was seen before)."""
    fp = first_seen_pairs(a, b)
    cnt, _ = window_stats(fp.a.to_numpy(), fp.ts.to_numpy(), np.ones(len(fp)), np.asarray(a, dtype=object), ts, None)
    key = pd.Series(list(zip(a, b)))
    fpm = {(x, y): s for x, y, s in zip(fp.a, fp.b, fp.ts)}
    seen = np.array([(fpm.get(k, np.inf) < s) for k, s in zip(key, ts)])
    return cnt, seen

F = pd.DataFrame(index=t.index)
kind = t.txn_kind
for k in ["checkout", "refund", "payout", "p2p_transfer"]:
    F[f"is_{k}"] = (kind == k).astype(int)

# ---------------------------------------------------------------- 2. base transaction features
F["amount"] = t.amount
F["amount_log"] = np.log1p(t.amount)
F["hour"] = t.hour; F["day_of_week"] = t.day_of_week; F["day_of_month"] = t.day_of_month
F["is_weekend_sa"] = t.is_weekend_sa
F["is_night"] = t.hour.isin([0, 1, 2, 3, 4, 5]).astype(int)
F["is_from_store"] = t.is_from_store
F["is_installment"] = t.is_installment; F["installment_count"] = t.installment_count
F["is_vpn_or_proxy"] = t.is_vpn_or_proxy.fillna(0)
F["is_foreign_origin"] = (t.origin_country.fillna("SA") != "SA").astype(int)
F["has_device"] = t.device_id.notna().astype(int)
F["has_card"] = t.card_hash.notna().astype(int)
F["is_round_amount"] = (t.amount % 100 == 0).astype(int)
for col in ["type", "payment_method", "card_scheme", "os", "browser", "category"]:
    F[f"{col}_code"] = t[col].astype("category").cat.codes  # -1 = missing

# balance fix: raw old/new balance is inconsistent for 15% of checkouts -> flag, don't difference
bal_gap = (t.oldbalanceOrg - t.amount - t.newbalanceOrig).abs()
F["balance_mismatch"] = (bal_gap > 0.01).astype(int)
F["amount_to_balance"] = (t.amount / t.oldbalanceOrg.replace(0, np.nan)).clip(0, 5)

# ---------------------------------------------------------------- 3. customer / merchant context (leak columns excluded)
cc = c.set_index("customer_id")
F["customer_age"] = t.customer_age
acct_age = t.customer_account_age_days
F["pre_open_txn"] = (acct_age < 0).astype(int)          # 520 rows: txn before account open
F["account_age_days"] = acct_age.clip(lower=0)
F["kyc_level_ord"] = t.kyc_level.map({"basic": 0, "standard": 1, "full": 2})
cust = t.customer_id.map
F["kyc_not_verified"] = cust(cc.kyc_status.ne("verified").astype(int))
F["pep_flag"] = cust(cc.pep_flag)
F["risk_rating_ord"] = cust(cc.risk_rating.map({"low": 0, "medium": 1, "high": 2}))
F["monthly_income"] = cust(cc.monthly_income_sar)
F["amount_to_income"] = (t.amount / F.monthly_income).clip(0, 50)
F["id_type_iqama"] = cust(cc.id_type.eq("iqama").astype(int))
F["is_non_saudi"] = cust(cc.nationality.ne("SA").astype(int))
F["kyc_age_days"] = cust((c.set_index("customer_id").kyc_verified_date - c.set_index("customer_id").account_open_date).dt.days)
F["has_second_card"] = cust(cc.card_hash_2.notna().astype(int))
# customer's phone/card reuse (identity sharing; computed on static tables, no label info)
ph = c.phone_hash.map(c.phone_hash.value_counts()); cd = c.card_hash_1.map(c.card_hash_1.value_counts())
F["cust_shared_phone"] = cust(pd.Series((ph > 1).astype(int).to_numpy(), index=c.customer_id))
F["cust_shared_card"] = cust(pd.Series((cd > 1).astype(int).to_numpy(), index=c.customer_id))

mm = m.set_index("merchant_id")
mer = t.merchant_id.map
F["merchant_age_days"] = t.merchant_age_days
F["kyb_risk_score"] = mer(mm.kyb_risk_score)
F["kyb_status_ord"] = mer(mm.kyb_status.map({"verified": 0, "simplified_review": 1, "pending_documents": 2}))
F["expected_monthly_volume"] = mer(mm.expected_monthly_volume_sar)
F["has_physical_store"] = mer(mm.has_physical_store)
F["mer_vat_inconsistent"] = mer(((mm.vat_registered == 0) & mm.vat_number.notna()).astype(int))
exp = mer(mm.cr_expiry_date)
F["mer_cr_expired_at_txn"] = (exp < t.timestamp).astype(float).where(exp.notna())  # replaces useless cr_status
dir_n = m.cr_director_id_hash.map(m.cr_director_id_hash.value_counts())
F["mer_shared_director"] = mer(pd.Series((dir_n > 1).astype(int).to_numpy(), index=m.merchant_id))
F["mer_director_pep"] = mer(mm.cr_director_pep_flag)
F["mer_free_email"] = mer(mm.email_domain_type.ne("business").astype(int))
F["mer_employees_band"] = mer(mm.employees_band.astype("category").cat.codes)
F["mer_mcc"] = mer(mm.mcc)

# basket fields (checkout only) -> -1 when structurally absent, plus has_basket flag
F["has_basket"] = t.basket_items.notna().astype(int)
F["basket_mismatch_score"] = t.basket_mismatch_score
F["category_mismatch_flag"] = t.category_mismatch_flag
F["basket_n_lines"] = t.basket_items.fillna("").map(lambda s: 0 if s == "" else s.count("|") + 1)

# ---------------------------------------------------------------- 4. refund / payout abuse features
amt_by_id = t.set_index("txn_id").amount
F["refund_amount_ratio"] = (t.amount / t.refund_of_txn_id.map(amt_by_id)).clip(0, 5)
F["minutes_since_checkout"] = t.minutes_since_checkout
F["refund_to_different_instrument"] = t.refund_to_different_instrument
F["payout_covers_n_checkouts"] = t.payout_covers_n_checkouts

# ---------------------------------------------------------------- 5. velocity & profiling per sender (per kind)
okey = (t.nameOrig + "|" + t.txn_kind).to_numpy(dtype=object)
ev_val = t.amount.to_numpy()
for w, lab in [(H, "1h"), (D, "24h"), (3 * D, "72h"), (7 * D, "7d")]:
    cn, sm = window_stats(okey, ts, ev_val, okey, ts, w)
    F[f"out_cnt_{lab}"] = cn; F[f"out_sum_{lab}"] = sm
F["out_amt_vs_24h_avg"] = F.amount / ((F.out_sum_24h / F.out_cnt_24h.replace(0, np.nan)).replace(0, np.nan))
g = t.assign(_k=okey).groupby("_k")
F["out_txn_index"] = g.cumcount()
prev_ts = g.timestamp.shift(1)
F["secs_since_prev_txn"] = (t.timestamp - prev_ts).dt.total_seconds()
cs, cs2 = g.amount.cumsum() - t.amount, (t.amount ** 2).groupby(okey).cumsum() - t.amount ** 2
k = F.out_txn_index
mean = cs / k.replace(0, np.nan); var = (cs2 / k.replace(0, np.nan) - mean ** 2).clip(lower=0)
F["amount_z_vs_own_history"] = ((t.amount - mean) / np.sqrt(var).replace(0, np.nan)).where(k >= 5).clip(-10, 10)
F["amount_vs_prev_max"] = (t.amount / g.amount.cummax().shift(1).where(okey == pd.Series(okey).shift(1).to_numpy()).replace(0, np.nan)).clip(0, 50)
# familiarity: how often this customer used this category / this hour bucket before
t["_hb"] = t.hour // 6
for col, lab in [("category", "category"), ("_hb", "hour_bucket")]:
    same = t.assign(_k=okey).groupby(["_k", col]).cumcount()
    F[f"{lab}_freq_so_far"] = (same / k.replace(0, np.nan))
t.drop(columns="_hb", inplace=True)

# ---------------------------------------------------------------- 6. receiver side + graph (causal)
dkey = t.nameDest.to_numpy(dtype=object)
for w, lab in [(D, "24h"), (7 * D, "7d")]:
    cn, sm = window_stats(dkey, ts, ev_val, dkey, ts, w)
    F[f"in_cnt_{lab}"] = cn; F[f"in_sum_{lab}"] = sm
F["dest_unique_senders_so_far"], _ = distinct_before(t.nameDest, t.nameOrig)
F["orig_unique_counterparties_so_far"], F["pair_seen_before"] = distinct_before(t.nameOrig, t.nameDest)
F["pair_seen_before"] = F.pair_seen_before.astype(int)
F["pair_count_so_far"] = t.groupby(["nameOrig", "nameDest"]).cumcount()
fp = first_seen_pairs(t.nameOrig, t.nameDest); fpm = {(a, b): s for a, b, s in zip(fp.a, fp.b, fp.ts)}
F["bidirectional_pair"] = [int(fpm.get((b, a), np.inf) < s) for a, b, s in zip(t.nameOrig, t.nameDest, ts)]
F["in_out_ratio_7d"] = (F.in_sum_7d + 1) / (F.out_sum_7d + 1)

# ---------------------------------------------------------------- 7. device / IP sharing (causal graph links)
cid = t.customer_id
F["device_n_customers_so_far"], dev_seen = distinct_before(t.device_id, cid)
F["device_new_for_customer"] = np.where(t.device_id.notna() & cid.notna(), (~dev_seen).astype(int), np.nan)
F["device_other_customers"] = (F.device_n_customers_so_far - dev_seen.astype(int)).clip(lower=0)
F["ip_subnet_n_customers_so_far"], sub_seen = distinct_before(t.ip_subnet_hash, cid)
F["ip_subnet_other_customers"] = (F.ip_subnet_n_customers_so_far - sub_seen.astype(int)).clip(lower=0)
F["ip_n_customers_so_far"], _ = distinct_before(t.ip_hash, cid)
dfs = t.device_id.map(dv.set_index("device_id").first_seen)
F["device_age_days"] = (t.timestamp - dfs).dt.days
F["is_emulator"] = t.device_id.map(dv.set_index("device_id").is_emulator)
F["device_is_primary"] = np.where(cid.notna() & t.device_id.notna(), (t.device_id == cid.map(cc.primary_device_id)).astype(int), np.nan)
F["cards_per_device_so_far"], _ = distinct_before(t.device_id, t.card_hash)
F["customers_per_card_so_far"], _ = distinct_before(t.card_hash, cid)

# ---------------------------------------------------------------- 8. merchant dynamics (checkout / refund / payout streams)
mkey = t.merchant_id.to_numpy(dtype=object)
isco, isre = (kind == "checkout").to_numpy(), (kind == "refund").to_numpy()
def mstream(mask, W):
    return window_stats(mkey[mask], ts[mask], ev_val[mask], mkey, ts, W)
co_cnt_all, _ = mstream(isco, None); re_cnt_all, _ = mstream(isre, None)
F["mer_refund_rate_so_far"] = (re_cnt_all / np.where(co_cnt_all == 0, np.nan, co_cnt_all))
co7, co7s = mstream(isco, 7 * D); re7, re7s = mstream(isre, 7 * D)
F["mer_checkout_cnt_7d"] = co7; F["mer_refund_cnt_7d"] = re7
F["mer_refund_rate_7d"] = re7 / np.where(co7 == 0, np.nan, co7)
_, co30s = mstream(isco, 30 * D)
F["mer_volume_30d_vs_expected"] = (co30s / F.expected_monthly_volume.replace(0, np.nan)).clip(0, 20)
F["payout_vs_7d_sales"] = np.where(kind == "payout", t.amount / (co7s + 1), np.nan)
F["mer_unique_customers_so_far"], _ = distinct_before(t.merchant_id.where(isco), cid)

# ---------------------------------------------------------------- 9. targets + entity-disjoint split
F = F.copy()
F.insert(0, "txn_id", t.txn_id); F.insert(1, "timestamp", t.timestamp)
keys = ["nameOrig", "nameDest", "customer_id", "merchant_id", "device_id", "ip_subnet_hash", "card_hash"]
for kcol in reversed(keys): F.insert(2, kcol, t[kcol])
F["isFraud"] = t.isFraud; F["isMoneyLaundering"] = t.isMoneyLaundering

# group key: fraud scenarios stay whole; everything else grouped by customer (merchant for payouts)
crole, cscn = c.set_index("customer_id").gt_role, c.set_index("customer_id").gt_scenario_id
mrole, mscn = m.set_index("merchant_id").gt_role, m.set_index("merchant_id").gt_scenario_id
fraud_cust_roles = {"ring_member", "refund_abuse_accomplice", "family_member"}
fraud_mer_roles = {"ring_merchant", "refund_abuse_merchant"}
g_cust = t.customer_id.map(cscn).where(t.customer_id.map(crole).isin(fraud_cust_roles))
g_mer = t.merchant_id.map(mscn).where(t.merchant_id.map(mrole).isin(fraud_mer_roles))
group = g_cust.fillna(t.customer_id).fillna(g_mer).fillna(t.merchant_id)  # a customer never straddles splits
rng = np.random.default_rng(42)
assign = {}
scen_type = t.dropna(subset=["gt_scenario_id"]).groupby("gt_scenario_id").gt_scenario_type.first()
fraud_scn = t[t.isFraud == 1].gt_scenario_id.dropna().unique()
for typ in ["collusion_ring", "refund_payout_abuse"]:
    ids = sorted([s for s in fraud_scn if scen_type.get(s) == typ]); rng.shuffle(ids)
    a, b = int(round(.6 * len(ids))), int(round(.8 * len(ids)))
    for i, s in enumerate(ids): assign[s] = "train" if i < a else "val" if i < b else "test"
def bucket(x):
    if x in assign: return assign[x]
    h = int(hashlib.md5(f"42|{x}".encode()).hexdigest(), 16) % 100
    return "train" if h < 60 else "val" if h < 80 else "test"
F["split"] = group.map(bucket)
F["split_group"] = group

# ---------------------------------------------------------------- 10. fill structural nulls, write
META = ["txn_id", "timestamp"] + keys + ["isFraud", "isMoneyLaundering", "split", "split_group"]
feat_cols = [x for x in F.columns if x not in META]
F[feat_cols] = F[feat_cols].replace([np.inf, -np.inf], np.nan).fillna(-1)   # -1 = not applicable / no history
F.to_parquet(f"{OUT}/features.parquet", index=False)
eval_meta.assign(split=F.split.values).to_csv(f"{OUT}/eval_only_ground_truth.csv.gz", index=False)
json.dump(feat_cols, open(f"{OUT}/feature_list.json", "w"), indent=1)

# cleaned entity tables for the graph / profiling engines: label-bearing columns removed
c.drop(columns=["gt_role", "gt_scenario_id"]).to_csv(f"{OUT}/customers_clean.csv", index=False)
m.drop(columns=["gt_role", "gt_scenario_id", "cr_status"]).to_csv(f"{OUT}/merchants_clean.csv", index=False)
dv.drop(columns=["device_kind"]).to_csv(f"{OUT}/devices_clean.csv", index=False)

print("features:", len(feat_cols), "rows:", n)
S = F.groupby("split").agg(rows=("txn_id", "size"), fraud=("isFraud", "sum"), aml=("isMoneyLaundering", "sum"))
S["fraud_rate"] = (S.fraud / S.rows).round(4)
print(S)
